"""Supplementary complete-reference calibration, after a material kernel difference."""

import json
import time
from pathlib import Path

from resume_study.config import Model
from resume_study.experiment import file_hash
from resume_study.inference import hardware, load_backend, versions
from resume_study.pilot import parse_pilot
from resume_study.results import append_record, atomic_json, read_records, write_csv

root = Path.cwd()
primary = root / "results/qwen4b_pilot_20261112"
out = root / "results/qwen4b_eager_reference_check"
assert not (out / "results.jsonl").exists()
manifest = json.loads((primary / "manifest.json").read_text())
assert manifest["status"] == "complete"
model = Model.model_validate({**manifest["config"]["model"], "attention_implementation": "eager"})
conditions = [c for c in json.loads((primary / "conditions.json").read_text())
              if c["block"] == "shared_reference" and c["repetition"] == 1]
prior = {r["condition_id"]: r for r in read_records(root / "results/qwen4b_attention_check/results.jsonl")}
engine = load_backend(model)
rows = []
for condition in sorted(conditions, key=lambda c: c["condition_id"]):
    fields = {k: v for k, v in condition.items() if k != "messages"}
    if condition["condition_id"] in prior:
        old = prior[condition["condition_id"]]
        assert old["prompt_hash"] == condition["prompt_hash"]
        row = {**fields, **old, "source": "earlier paired eager check"}
    else:
        start = time.perf_counter()
        raw = engine.generate([condition["messages"]], [condition["suggested_seed"]])[0]
        row = {**fields, "raw_response": raw, **parse_pilot(raw),
               "inference_seconds": time.perf_counter() - start, "source": "new eager reference check"}
    append_record(out / "results.jsonl", row)
    rows.append(row)
    print(json.dumps({"completed": len(rows), "id": row["condition_id"], "score": row["score"],
                      "status": row["parsing_status"]}), flush=True)
write_csv(out / "results.csv", rows, fieldnames=sorted({key for row in rows for key in row}))
pairs = []
by_base = {r["baseline_id"]: r for r in rows}
for high in rows:
    if high["qualification"] == "HIGH":
        low = by_base[high["baseline_id"].removesuffix("HIGH") + "LOW"]
        valid = high["parsing_status"] == low["parsing_status"] == "valid"
        pairs.append({"job_family": high["job_family"], "profile": high["profile"],
                      "high_score": high["score"], "low_score": low["score"],
                      "gap": high["score"] - low["score"] if valid else None})
atomic_json(out / "summary.json", {"model": model.model_dump(), "engine": engine.metadata,
            "hardware": hardware(), "versions": versions(), "n": len(rows), "n_new_calls": len(rows)-2,
            "n_valid": sum(r["parsing_status"] == "valid" for r in rows), "qualification_pairs": pairs,
            "script_sha256": file_hash(Path(__file__)),
            "primary_results_sha256": file_hash(primary / "results.jsonl"),
            "earlier_eager_results_sha256": file_hash(root / "results/qwen4b_attention_check/results.jsonl"),
            "interpretation": "Exploratory reference-only follow-up, not a replacement for or pooled with the frozen SDPA pilot."})
write_csv(out / "qualification_pairs.csv", pairs)
print(json.dumps(pairs), flush=True)
  
