"""One-off paired attention check on frozen pilot messages; no competing model process."""

import json
import shutil
import time
from pathlib import Path

from resume_study.config import Model, digest
from resume_study.experiment import file_hash, git_state, model_record_fields
from resume_study.inference import hardware, load_backend, versions
from resume_study.generate_resumes import ENV
from resume_study.pilot import parse_pilot
from resume_study.results import append_record, atomic_json, read_records, write_csv

root = Path.cwd()
source = root / "results/qwen4b_pilot_20261112"
directory = root / "results/qwen4b_attention_check"
manifest = json.loads((source / "manifest.json").read_text())
assert manifest["status"] == "complete", "Finish the primary run before this check"
conditions = json.loads((source / "conditions.json").read_text())
original = {r["condition_id"]: r for r in read_records(source / "results.jsonl")}
chosen = {"DATA_A_LOW__NAME_WF_01__R1", "OPS_A_LOW__REF__R1",
          "SWE_B_HIGH__REF__R1", "OPS_A_HIGH__GEO_01__R1"}
model_data = manifest["config"]["model"]
model_data["attention_implementation"] = "eager"
model = Model.model_validate(model_data)
if (directory / "results.jsonl").exists():
    raise ValueError("Attention-check results already exist")
engine = load_backend(model)
rows = []
for condition in sorted(conditions, key=lambda c: c["condition_id"]):
    if condition["condition_id"] not in chosen:
        continue
    start = time.perf_counter()
    raw = engine.generate([condition["messages"]], [condition["suggested_seed"]])[0]
    parsed = parse_pilot(raw)
    prior = original[condition["condition_id"]]
    row = {"condition_id": condition["condition_id"], "prompt_hash": condition["prompt_hash"],
           **model_record_fields(model), "raw_response": raw, **parsed,
           "inference_seconds": time.perf_counter() - start,
           "sdpa_parsing_status": prior["parsing_status"], "sdpa_score": prior["score"],
           "same_raw": raw == prior["raw_response"],
           "same_score": parsed["score"] == prior["score"]}
    append_record(directory / "results.jsonl", row)
    rows.append(row)
    print(json.dumps(row), flush=True)
atomic_json(directory / "manifest.json", {"comparison": "MPS float16 eager vs SDPA, other settings fixed",
            "primary_results_sha256": file_hash(source / "results.jsonl"), "model": model.model_dump(),
            "engine": engine.metadata, "hardware": hardware(), "versions": versions(), "git": git_state(root),
            "script_sha256": file_hash(Path(__file__)), "conditions": sorted(chosen)})
shutil.copyfile(source / "conditions.json", directory / "primary_conditions.json")
write_csv(directory / "results.csv", rows)
control_resume = """Name: Jordan Taylor
Location: Boston, MA

EDUCATION
High school diploma, 2026.

EXPERIENCE
Retail Cashier, Fictional Corner Store, June-August 2025
- Processed cash payments and restocked shelves using an existing checklist.
- Answered customer questions and reported problems to a supervisor.

SKILLS
Cash handling, shelf stocking, customer service.

AVAILABILITY
Available for remote work within the United States.
"""
template = ENV.from_string((source / "inputs/templates/pilot_evaluation.j2").read_text())
system = (source / "inputs/templates/pilot_system.txt").read_text()
controls = []
for family in ("software_engineering", "data_analysis"):
    job = (source / "inputs/resumes-and-shi/jobs" / f"{family}.txt").read_text()
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": template.render(resume=control_resume, job_description=job)}]
    start = time.perf_counter()
    raw = engine.generate([messages], [101])[0]
    row = {"condition_id": "extra_negative_control_" + family, "job_family": family,
           "excluded_from_primary_pilot": True, "attention": "eager", "messages": messages,
           "prompt_hash": digest(messages), "raw_response": raw, **parse_pilot(raw),
           "inference_seconds": time.perf_counter() - start}
    append_record(directory / "negative_controls.jsonl", row)
    controls.append(row)
    print(json.dumps(row), flush=True)
atomic_json(directory / "negative_controls_protocol.json", {
    "purpose": "Supplementary out-of-dataset sanity check; no required SQL/Python/testing evidence supplied",
    "source_resume": control_resume, "model": model.model_dump(), "engine": engine.metadata,
    "excluded_from_primary_pilot": True, "n": len(controls)})
print(digest(rows), flush=True)
  
